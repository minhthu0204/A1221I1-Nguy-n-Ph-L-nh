package com.example.formvalidation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FormValidationApplicationTests {

    @Test
    void contextLoads() {
    }

}
